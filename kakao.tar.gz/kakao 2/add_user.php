<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $db_host = $_POST['dbHost'];
    $db_username = $_POST['dbUsername'];
    $db_password = $_POST['dbPassword'];
    $db_name = $_POST['dbName'];
    $username = $_POST['username'];

    $conn = new mysqli($db_host, $db_username, $db_password, $db_name);

    if ($conn->connect_error) {
        die("데이터베이스 연결 실패: " . $conn->connect_error);
    }

    $sql = "INSERT INTO users (username) VALUES ('$username')";

    if ($conn->query($sql) === TRUE) {
        echo "새로운 사용자가 추가되었습니다.";
    } else {
        echo "사용자 추가 실패: " . $conn->error;
    }

    $conn->close();
}
?>
