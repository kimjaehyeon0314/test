<?php
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // 사용자로부터 입력받은 데이터베이스 연결 정보 가져오기
    $db_host = $_GET['dbHost'];
    $db_username = $_GET['dbUsername'];
    $db_password = $_GET['dbPassword'];
    $db_name = $_GET['dbName'];

    // 데이터베이스 연결
    $conn = new mysqli($db_host, $db_username, $db_password, $db_name);

    // 연결 확인
    if ($conn->connect_error) {
        die("데이터베이스 연결 실패: " . $conn->connect_error);
    }

    // 사용자 이름 가져오기
    $sql = "SELECT username FROM users";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo $row["username"] . "<br>";
        }
    } else {
        echo "유저 이름이 없습니다.";
    }

    $conn->close();
}
?>
